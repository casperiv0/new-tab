# Changelog

## 0.3.0

- New settings UI
- General improvements

## 0.2.0

- General improvements
- Add weather widget

## 0.1.1

- Bug fixes
- Code improvements

## 0.1.0

- Initial Release
